# 插件开发：浏览器侧 tavernUi

浏览器侧 `ctx.tavernUi`：显示媒体、正文标记、按钮、面板、舞台与声音。

浏览器侧的代码运行在 DSH 页面里，使用 DSH 提供的 `react`。插件的 `render` 函数返回 React 元素；出错时只影响这个元素，正文其余部分照常显示。

## `registerGameModeView({ name, render, presentation?, lobby? })`

为宿主侧 `gameMode` 注册玩法界面，两端插件归属和 `name` 必须一致。注册随插件卸载撤销。

- `presentation: 'page'` 使用独立游戏页面，隐藏正文内重复的玩法界面；默认在正文内展示。宿主提供进入游戏、返回酒馆和再次进入的入口。
- `presentation: 'stage'` 另需 `stage: { scene(props), hud?(props) }`，让玩法借用舞台（见下文「舞台借用」）；舞台不可用时与 `'page'` 完全相同，`render` 仍是页面视图。缺少 `stage.scene` 函数或 `stage.hud` 不是函数时注册直接报错。
- 可选 `lobby({ busy, start })` 返回开局大厅，调用 `start()` 创建本局；当前大厅入口不接收自定义开局参数，服务端 `create` 收到的 `input` 为 null。
- `render({ gameId, data, revision, busy, paused, error, resume, advance, page, foreground })` 返回 React 元素。`data` 仅为服务端 `project` 的玩家可见投影；`page` 表示独立页面，`foreground` 表示原生正文投射模式。
- `advance(input)` 提交结构化行动，成功返回 true，失败返回 false。自动推进应尊重 busy、paused、error，按 revision 去重；`resume()` 清除错误并恢复推进。

宿主提供停止、回退和撤销回退控件；停止、失败或回退后暂停自动推进。页面关闭会卸载视图，已提交状态仍保存；再次进入读取同一局进度。自动推进由页面驱动，插件应在组件卸载时清理定时器和订阅。

宿主注册、成员代理与存档契约见[玩法 API](plugin-api-game.md)。

### 舞台借用（`presentation: 'stage'`）

玩法把一局的舞台整体借来演：人物站位、台词、配音和一块自绘的控制面板。舞台只认通用的 `StageScene`，不知道具体玩法；适配全部由卡完成。

```js
ctx.tavernUi.registerGameModeView({
  name: 'werewolf',
  presentation: 'stage',
  render: PageView,                  // 舞台不可用时的页面视图
  stage: {
    scene: props => props.data ? { actors: [...], lines: [...] } : null,
    hud: Hud                         // 可选，React 组件
  }
})
```

**借用的语义**

- 借用是**整份快照、只在内存**：每次渲染由 `scene(props)` 重新给出完整场景，不是增量指令。它从不写入 Story Timeline、导演的增量/持久舞台状态或任何存档；归还后舞台回到借用前的样子。
- 同一局同一时间只有一份借用，由舞台的 `stageLeases` 登记（挂在已有的 `tavernStageFrontend` 上）。它与上文 `acquireLease` 的「占用锁」无关。
- 以下任一情况即归还，正文从原来的页继续：`scene()` 返回 `null`、玩法快照变为空、视图注销（含插件卸载）、这一局的舞台卸载。

**页面回退**

只要这一局没有舞台在消费借用，就渲染 `render` 页面视图，与 `presentation: 'page'` 相同。这包括：玩家关闭舞台（模组四态开关或本卡设置）、舞台未加载、舞台出错、片段导出。`scene()` 抛错时同样回到页面视图，并显示错误。不用舞台的卡不会加载舞台代码。

**`scene(props)` → `StageScene | null`**

`props` 与 `render` 相同（`gameId`、`data`、`revision`、`busy`、`paused`、`error`、`resume`、`advance`、`page`、`foreground`），另加 `GameControls`。

```js
{
  actors: [{ name, emotion?, focus? }],          // 从左到右，最多 4 个
  lines:  [{ id, speaker?, text, emotion? }]     // 只追加；没有 speaker 是旁白
}
```

- `actors`：按顺序保留前 4 个能解析的人物；认不出、有歧义或重复的名字直接跳过。`focus: true` 的人物（只认第一个）点亮并向前一步，其余人物变暗；说话人仍有原有的高亮。
- `lines`：每行要有稳定的 `id`，新内容只追加在末尾，不改已有行的 `id`。台词经舞台自己的控制器播放：皮肤的文本框、AUTO、SKIP、LOG、菜单，配音走舞台原有的语音通道，一行在首次未读显示时朗读。
- 名字只经已有的 `resolveFigureName` 在本卡绑定的素材包里解析（精确名字或别名）。**一个名字对应多个人物即视为认不出**：没有立绘、没有配音，不猜。说话人认不出的行保留文字，但不配音。
- `emotion` 经舞台已有的情绪归一化（本卡情绪表），认不出就不带情绪。
- 手机上只站一个人物：有 `focus` 时是它，否则是最新一行的说话人。

**`read`：阅读游标**

游标由舞台按行 `id` 持有，卡不要自己推进。`read = { lineId, unread }`：`lineId` 是最后读完的一行（还没读过为 `null`），`unread` 是未读行数。玩家翻过最后一行后，新追加的行接着读；游标所在行消失时从第一行重读。

**`hud(props)`：舞台上的控制面板**

`hud` 收到 `{ ...props, read, device, Avatar, GameControls }`：

- `device`：`'desktop'`、`'mobile-landscape'` 或 `'mobile-portrait'`（舞台已有的设备档位）。
- `Avatar({ name, size? })`：场景里出现的名字解析出的人物头像，`size` 默认 32（px）；认不出时显示名字首字的圆形占位。
- `GameControls`：宿主的「停止 / 回退一步 / 撤销回退」按钮组件，页面视图里的同一组，可放进面板。

面板区域位于顶栏与文本框之间，在皮肤的主题作用域内（`data-device` 标在容器上）。卡的样式**只用 `--gal-ui-*` 令牌**（如 `--gal-ui-ink`、`--gal-ui-muted`、`--gal-ui-surface`、`--gal-ui-surface-2`、`--gal-ui-line`、`--gal-ui-accent`、`--gal-ui-accent-ink`、`--gal-ui-radius`、`--gal-ui-font`、`--gal-ui-shadow`、`--gal-ui-focus`），这样换皮肤自动跟着变。容器是 `pointer-events: none`，点击会穿透到舞台；卡自己的按钮等可交互元素要设回 `pointer-events: auto`。`hud` 抛错时面板显示「玩法面板出错了，舞台仍可继续」，舞台照常运行。

## `registerMediaRenderer(kind, render)`

为插件自定义的 `kind`（`<插件名>/<类型>`）提供显示方式，比如边下载边显示、带播放器的卡片。`image`、`video`、`audio` 由 Tavern 显示，不能替换。

```js
render({ item, gameId, turn })  // item 与 list 返回的字段相同，另有 url（有附件时为附件地址）
```

没有注册显示方式的自定义媒体项不显示。

## `registerTextMarker({ pattern, render })`

正文里匹配 `pattern`（正则）的已有片段交给插件显示。生成过程中也会调用，此时 `streaming` 为 `true`。这是上游保留的渲染接口；舞台效果走导演命令，不借此定义新的正文协议。

```js
render({ match, groups, gameId, turn, streaming })  // 返回 React 元素；返回 null 或出错时原样显示这段文字
```

- 普通正文里，标记就地替换。
- 写在人物卡自己的 HTML 界面（状态栏、美化面板）里的标记，无法拆开那段 HTML，会从界面里去掉，显示在那段界面之后。
- 原始片段仍留在对话历史里，后续轮次模型能看到；渲染不修改历史内容。

## `registerMessageAction({ id, label, when, run })`

在每条已写完的助手消息下方加一个按钮，例如「配图」「重画」。`when(context)` 决定是否显示（不传则总是显示），点击时调用 `run(context)`，`run` 可以是异步函数，执行期间按钮不可再点。

```js
context = { gameId, turn, settled, text }
```

`text` 是这条消息的正文（模型写出的原文），可用来只在合适的消息下显示按钮，例如正文里已经写到某段内容时就不显示。

## `registerComposerAction({ id, label, when, run })`

在输入框上方的操作栏加一个按钮，针对当前最新一轮。模型正在生成时按钮不可点。

```js
context = { gameId, turn, busy }
```

想替换内置生图的插件就用这个入口。内置生图的入口在每轮正文下方的操作栏（图片图标），与插件按钮互不占位，由用户选择用哪个。

## `readPluginData()`、`savePluginData(data)`（第 3 版）

读写插件自己的数据，和宿主侧 `tavern.readPluginData()`、`tavern.savePluginData({ data })` 是同一份（见[媒体与数据](plugin-api-data.md)）。都返回 Promise；`savePluginData` 传 `null` 清除。

## `registerIllustrator({ kinds, draw?, redraw?, editPrompt?, add?, cancel?, action? })`（第 5 版）

生图插件接管 Tavern 自己的配图界面：每轮的「为这一轮配图」按钮，以及正文里包住插件图片的插图卡。插图卡负责显示、版本切换、删除、进度和取消按钮，插件只负责出图。`kinds` 是插件自己的媒体类型；这些类型的媒体项由插图卡显示，不再走 `registerMediaRenderer`。

每个处理函数收到 `{ gameId, turn, textVersion, item }`，可以返回 Promise，抛错会显示在卡片上。只提供了哪个函数，卡片上就出现对应的按钮：

- `draw`：为这一轮配图（不提供就没有配图按钮，比如插件的配图功能被关掉时；已有插图照常由插图卡显示），通常 `attach` 一个 pending 占位，出图后 `update` 成 ready。等它返回期间，正文里显示「正在整理画面…」；返回 `{ notice }` 时把说明留在原处几秒（比如「本轮跳过配图：没有合适的画面」），抛错则显示失败原因。不必另弹提示。
- `redraw`：按这张图的提示词再画；新图换上后旧图成为早期版本。
- `revise`：重新整理提示词再画，多收到玩家写的 `instruction`（可能为空，空时重新构思画面）。提供了它，「重画」会打开面板，让玩家在「同提示词重画」（`redraw`）和「按意见重画 / 重新整理提示词」（`revise`）之间选。
- `editPrompt`：「改提示词」，多收到 `prompt`。
- `add`：「新增插图」，多收到玩家写的 `instruction`（可能为空）。
- `cancel`：pending 或 `activity.cancellable` 时的「取消」。
- `action`：媒体项 `actions` 里的按钮，多收到 `actionId`。

插图卡只读标准字段：`status`、`progress`、`error`、`prompt`、`activity`、`actions`，插件自己的 `data` 它不读。

## `listIllustrations()`（第 4 版）

原本列出 Tavern 自带场景生图画过的插图。Tavern 已不再保留这些旧图（配图都由插件生成），现在总是返回空列表；方法保留，旧插件调用不会出错。插件自己挂的媒体请用插件媒体接口读取。

## `getGames(gameIds)`（第 4 版）

按 `gameId` 查游戏名称，返回 Promise `{ [gameId]: { title, cardName } }`；已删除或不存在的游戏不在结果里。一次最多 500 个。

## `callHost(name, args)`（第 2 版）

调用宿主侧用 `tavern.handle(name, handler)` 注册的处理函数，返回一个 Promise，结果是处理函数的返回值。

```js
ctx.tavernUi.registerMessageAction({
  id: 'redraw', label: '重画',
  run: ({ gameId, turn }) => ctx.tavernUi.callHost('dsh-tavern-xxx/redraw', { gameId, turn }),
})
```

处理函数不存在（插件宿主侧没加载、或没注册这个名字）时失败，错误码 `TAVERN_PLUGIN_NOT_FOUND`。

## `assetUrl(path)`（第 2 版）

插件文件夹里 `assets/` 下文件的地址，用于图片、地图、音效、音乐、字体等：

```js
h('img', { src: ctx.tavernUi.assetUrl('map/forest.png') })
new Audio(ctx.tavernUi.assetUrl('sfx/hit.mp3')).play()
```

- `path` 是相对 `assets/` 的路径，不能含 `..` 或以 `.` 开头的部分。
- 只提供 `assets/` 下的文件，插件文件夹里的代码和设置不会被公开；放进 `assets/` 的文件，打开酒馆页面的人都能读到，不要放密钥。
- 音频、视频支持拖动进度（按范围读取）；文件修改后浏览器会重新取。
- 插件按 `package.json` 的 `name` 认出自己（与浏览器侧 `factory` 返回的 `name` 相同）。只对放在 `plugins/` 文件夹里的插件有效。

## `watchState(gameId, name, listener)`（第 3 版）

先用当前的值调用一次 `listener(data)`，之后本插件宿主侧每次 `tavern.publishState` 同一个 `name` 时再调用（内容没变不调用）。没有发布过时收到 `null`。返回取消函数，插件卸载时自动取消。

## `getTurnState(gameId)`、`watchTurnState(gameId, listener)`（第 2 版）

`getTurnState` 返回 Promise，结果与宿主侧 `tavern.getTurnState` 相同。`watchTurnState` 先用当前状态调用一次 `listener(state)`，之后每次状态变化（开始或写完正文、结算开始或结束、回退等）再调用；返回取消函数，插件卸载时自动取消。只在这一局在当前页面打开时有通知。

## `watchReply(sessionId, listener)`（第 6 版）

读正在写的这条回复，**卡片工作台也能用**（其他 `getTurnState` 一类接口在工作台不可用）。先用当前状态调用一次 `listener(state)`，之后每次变化（逐字生成、写完、工具开始或结束、卡片落盘）再调用；返回取消函数，插件卸载时自动取消。只在这一局在当前页面打开时有通知。

```js
const stop = ctx.tavernUi.watchReply(gameId, (state) => {
  bubble.text = state.text
  bubble.streaming = state.streaming
  if (state.cardSaved) showBuiltCard(state.cardSaved)
})
```

| 字段 | 含义 |
|---|---|
| `mode` | `'card'` 是卡片工作台，`'story'` / `'script'` 是游玩 |
| `turn` | 这一轮的轮次（工作台里同样是 DSH 的轮次） |
| `text` | 最新一条助手回复的纯文本；生成中是当前已写出的部分 |
| `streaming` | 正在逐字写（已经拿到部分文字） |
| `busy` | 这一轮还在跑（生成正文或执行工具），此时 `text` 可能还是上一轮 |
| `tool` | 正在执行的工具名（如 `tavern_update_card`），拿不到时 `null` |
| `cardSave` | 工作台最近一次落盘：`{ turn, path, createsCard, changed }`，没有时 `null` |
| `cardSaved` | 这一轮刚创建的新卡路径（`createsCard`），否则 `null` |
| `changed` | 这一轮改过或创建了这张卡（含工具直接保存），否则 `false` |

工具调用不会改动 `text`；想在工作台里判断「建好了」，用 `cardSaved`，不要匹配正文。

## `watchWorkStatus(sessionId, listener)`、`getWorkStatus(sessionId)`（第 7 版）

读这一局现在在做什么，给桌宠、陪玩这类要跟着状态换表情的插件用。`watchWorkStatus` 先用当前状态调用一次 `listener(status)`，之后每次变化再调用，返回取消函数；只在这一局于当前页面打开时有通知。`getWorkStatus` 同步读当前值，不订阅。

```js
const stop = ctx.tavernUi.watchWorkStatus(gameId, (status) => {
  pet.face(status.state) // idle / thinking / working / waiting / success / error
})
```

| 字段 | 含义 |
|---|---|
| `state` | `idle` 空闲；`thinking` 正在写正文；`working` 正在跑工具或后台结算；`waiting` 在等玩家回答（`ask_user_question`）；`success` 刚忙完；`error` 出错 |
| `reason` | 细分来源：`idle` / `busy` / `streaming` / `tool` / `settlement` / `question` / `settled` / `load` |
| `busy` | 这一局现在是否在跑 |
| `turn` | 最新一轮的轮次；还没有正文时为 `0` |
| `tool` | 正在执行的工具名，拿不到时 `null` |
| `phase`、`role` | Tavern 的原始活动字段（`role` 如 `settlement`） |
| `error` | `state === 'error'` 时的原因，否则空字符串 |
| `updatedAt` | 这次状态的生成时刻 |

- `success` 只在**看着这一局从忙变闲**时出现，持续 4 秒后回到 `idle`；第一次订阅一个早就写完的局不会补一次成功。
- 换局、关掉这一局、插件卸载都会自动停掉订阅。
- 只读，不改变游戏。

## `onPlayEvent(listener)`（第 8 版）

玩家在当前页面里做了什么：选了哪个选项、一页读了多久、重播了语音、看到了报错。给游玩统计、陪玩这类插件用。每次动作之后调用 `listener(event)`，返回取消函数；插件卸载时自动停掉。

```js
const stop = ctx.tavernUi.onPlayEvent((event) => {
  if (event.type === 'page') stats.read(event.gameId, event.turn, event.dwellMs)
})
```

每个事件都有 `type`、`gameId`、`turn`（这一局最新的轮次，事件自带时以事件为准）和 `at`（毫秒时间戳），其余字段按类型：

| `type` | 何时 | 其余字段 |
|---|---|---|
| `choice` | 选了一个候选选项（输入框上方的候选，或舞台的选项） | `choiceIndex` |
| `input_rewrite` | 改写了自己的输入：编辑已发送的输入，或在舞台上改了撤回的那句再发 | `editChars` |
| `ai_edit` | 编辑了 AI 写的正文 | `editChars` |
| `regenerate` | 重新生成正文 | — |
| `native_error` | 一轮失败的报错出现在屏幕上（同一轮在本页只算一次） | `nativeTurn`：报错行上的 DSH 原生轮次（不是剧情轮次 `turn`） |
| `error` | 报错中心收到一条报错；`gameId` 为空字符串 | — |
| `voice_replay` | 点了语音按钮重播 | 舞台上另有 `page` |
| `page` | 舞台上离开一页（翻页、暂停阅读或关掉页面） | `page`、`dwellMs`（只算页面可见、未暂停的时间）、`skipped` |
| `auto_on`、`auto_off`、`skip` | 舞台的 AUTO 开关、开始快进 | — |

- 只有计数和序号，不含任何正文文字。`editChars` 是改动的字数（去掉前后相同的部分），不是长度差。
- 插件在这一局被关掉时收不到这一局的事件。
- 回调抛错会进报错中心；连续出错三次后这个回调被停掉。

## `acquireLease({ sessionId, scope, ttlMs?, reason? })`、`getLease(sessionId, scope)`、`watchLease(sessionId, scope, listener)`（第 7 版）

「占用锁」：同一局同一个 `scope` 同时只给一个插件。给桌宠这类会抢气泡、动作、舞台的插件协调用，避免两个插件同时说话或同时换画面。

```js
const lease = ctx.tavernUi.acquireLease({ sessionId: gameId, scope: 'voice', ttlMs: 30000, reason: '引导提问' })
try { /* 这段归我说话 */ } finally { lease.release() }
```

- `scope` 只能用小写字母、数字、点、下划线和连字符，以字母开头；建议用 `voice`、`bubble`、`stage`、`composer` 这类语义名。
- `ttlMs` 默认 30 秒，范围 1 秒–10 分钟。过期是懒判的：`getLease` 和下一次 `acquireLease` 会清掉，`watchLease` 会收到 `expired`。
- 返回 `{ leaseId, holder, expiresAt, renew(ttlMs?), release(), active() }`。`holder` 是插件名（`package.json` 的 `name`）。
- 别人持有这个 `scope` 时 `acquireLease` 抛错，`error.code === 'TAVERN_PLUGIN_LEASED'`，另带 `holder` 与 `expiresAt`；同一个插件重拿是续期，`leaseId` 不变。
- 续期时锁已经丢了，抛 `TAVERN_PLUGIN_LEASE_LOST`；`release()` 是幂等的。
- `getLease(sessionId, scope)` 返回当前持有者快照或 `null`；`watchLease` 先给一次当前值（`cause === 'current'`），之后在 `acquired` / `renewed` / `released` / `expired` 时回调，返回取消函数。
- 插件卸载时自动释放。Tavern 保证同一 `scope` 只有一个持有者；拿不到锁的插件应当自己让路（检查 `getLease` / `watchLease`），Tavern 不会替它改已经注册的界面。

## `registerReplyPresenter({ id, modes, present })`（第 6 版）

让插件把会话里的**已完成**回复折叠成一行，例如卡片工作台里已经由桌宠念过的提问。Tavern 在画每条助手消息时同步调用 `present(message)`；返回 `null` 或不认识就保持原文。

```js
ctx.tavernUi.registerReplyPresenter({
  id: 'question', modes: ['card'],
  present: ({ text }) => parseQuestion(text) ? { fold: { summary: '第 2 题：核心定位是什么？' } } : null,
})
```

- `message = { sessionId, turn, text, changed, streaming }`，`streaming` 恒为 `false`（生成中不调用）。
- 返回 `{ fold: { summary } }` 时，这条消息显示成 `🐾 摘要 · 展开`；`summary` 压成一行、最多 60 字，点击就地展开原文，再点「收起」回到一行。
- `modes` 目前只有 `'card'` 有效；同一会话注册多个时，按注册顺序取第一个返回非 `null` 的。
- `present` 必须同步且快；抛错会记到插件错误里，连续 3 次后这一会话不再调用它。插件卸载后恢复原文。
- 只修改显示，存档里的正文不变。

## `registerComposerSlot({ id, modes, render })`（第 6 版）

在输入框正上方加一块插件自己的界面（与对话栏同宽），可用于工作台引导员、剧情建议选项和状态栏。`modes` 默认 `['card']`；`['play']` 覆盖剧情与剧本模式，也支持内部模式名 `story` / `script`。

```js
ctx.tavernUi.registerComposerSlot({
  id: 'guide', modes: ['card'],
  render: ({ sessionId, busy }) => h(GuideDock, { sessionId, busy }),
})
```

- `render` 返回 React 元素或 null，收到 `{ sessionId, busy }`（`busy` 是这一轮是否在跑）。
- 建议按钮通过 `setInput({ gameId: sessionId, text })` 填写或 `submitInput({ gameId: sessionId, text })` 发送；停靠区之外的内置输入框始终保留。
- 同一会话只显示一个停靠区（先注册者），`modes` 不符合的会话不显示；插件卸载后移除。
- 高度由内容决定，最高 40vh，超出内部滚动；Tavern 会把输入区上移，不会盖住最新一条消息。
- 出错时只显示一行错误；卡内插件按它那张卡的局生效。

## `registerComposerTool({ id, modes, render })`（第 10 版）

在输入卡尾部的紧凑控制区（模型席与提交键同一行）放一个图标按钮。和 `registerComposerSlot` 的区别只有一条：**不占输入框上方的停靠区一行**，所以适合“只有一个图标”的入口（剧情罗盘、语音、开关类面板），不会把最新一条正文挤到输入区后面。

```js
ctx.tavernUi.registerComposerTool({
  id: 'compass', modes: ['play'],
  render: ({ sessionId, busy }) => h(IconButton, { sessionId, busy }),
})
```

- `render` 收到 `{ sessionId, busy }`，返回 React 元素或 null（不显示）；同一插件同名 id 不能重复注册，卸载后移除。
- 只放一个字形：这一行本来就窄，文字请写进 `title` 与 `aria-label`。
- 状态（已启用、正在跑、出错）用图标本身表达：加个小圆点或换图标，不要再展开成一行文字。
- 活动面板展开时宿主要把这一行收起来（`hidden`），所以承载的功能要能在别处完整操作；点击后用 `openPanel()` 打开完整界面。
- 宿主版本低于第 10 版时这个方法是 `undefined`：插件应退回 `registerComposerSlot`，不要直接调用。

## `setInput({ gameId, text })`、`submitInput({ gameId, text })`（第 2 版）

`setInput` 把文字填进这一局的输入框，不发送，玩家可以改了再发。`submitInput` 直接作为玩家输入发送并生成正文，返回 Promise（提交后完成，不等正文写完；要等结果用 `watchTurnState`）。正在生成时会排在当前这轮之后。这一局没有在当前页面打开时报错。

```js
ctx.tavernUi.submitInput({ gameId, text: '我举盾格挡，然后反击。' })
```

## `openOverlay({ gameId?, render, dismissible?, onClose? })`（第 2 版）

打开一层盖住整个页面的插件界面，适合战斗、地图这类需要大空间的玩法。返回 `{ close }`。

```js
const overlay = ctx.tavernUi.openOverlay({
  gameId,
  render: ({ gameId, close }) => h(BattleScreen, { gameId, onFinish: close }),
  onClose: () => { /* 界面关闭后 */ },
})
```

- `render` 收到 `{ gameId, close }`，返回 React 元素；界面自己负责提供关闭的按钮。
- 按 Esc 关闭；`dismissible: false` 时 Esc 不关闭，只能调用 `close`。
- 关闭时调用一次 `onClose`。插件卸载时界面自动关闭。界面出错时显示一行错误和关闭按钮。

## `registerPanel({ id, title, render })`（第 2 版）

在右侧栏加一页插件自己的面板，比如记忆、锚点或状态一览。玩家从侧栏的「＋」里打开，面板显示在「插件」一组。

```js
ctx.tavernUi.registerPanel({ id: 'memory', title: '记忆', render: ({ gameId, visible }) => h(MemoryPanel, { gameId }) })
```

- `id` 用小写字母、数字、点、下划线和连字符；`title` 1–40 字。
- `render` 收到当前侧栏对应的 `gameId`，返回 React 元素；没有打开游戏时，Tavern 显示提示，不调用 `render`。
- 面板出错时只显示一行错误，不影响侧栏其他页。插件卸载时面板自动移除。

## `registerStartGroup({ title, tabs })`（第 2 版）

把插件自己的几个侧栏页归成一组，显示在侧栏开始页（点「＋」看到的那一页）。不声明时，`registerPanel` 的面板在「插件」组，直接用 DSH `betterSidebar.registerTab` 注册的页在「其他」组。

```js
ctx.tavernUi.registerStartGroup({ title: '叙事锚定', tabs: ['narrative-anchor:settings', 'narrative-anchor:state', 'memory'] })
```

- `title` 1–20 字；`tabs` 1–20 个侧栏页 id，按顺序显示。带 `:` 的是侧栏页的完整 id（`registerTab` 时的 `id`）；不带 `:` 的是本插件 `registerPanel` 的 `id`。
- 插件分组排在 Tavern 自带的「本局」「资料库」「偏好」之后、「插件」之前，按注册顺序。Tavern 自己的页不能移进插件分组；同一页被几个分组声明时只显示在第一个里。
- 几个插件用同一个 `title` 时合成一节，节内按侧栏顺序排列；例如舞台和配音插件都声明「舞台装置」。
- 列出的页没有注册时不显示；整组都没有可显示的页时，整组隐藏。插件卸载时分组自动移除。

## `registerCardListView({ id, label, render })`（第 2 版）

换一种方式显示人物卡列表，例如按分组排的书架、带更多信息的卡片。「人物卡库」和「选择人物卡 · 开始游玩」两处都会用到。列表上方本来就有 Tavern 自带的「列表 / 宫格」切换，注册后多出一个 `<label>`，用户选哪个，这台浏览器就记住哪个。搜索、分组筛选、批量管理的工具栏（全选、删除、移动分组）仍由 Tavern 显示在列表上方，插件只负责画卡片。

```js
ctx.tavernUi.registerCardListView({
  id: 'grid', label: '宫格',
  render({ place, cards, busy, selecting, isSelected, toggle, open, menu, mention }) {
    return h('div', { className: 'my-grid' }, cards.map(card => h('button', {
      key: card.path, disabled: busy, onClick: () => open(card.path),
      'aria-pressed': selecting ? isSelected(card.path) : undefined,
    }, card.imageUrl ? h('img', { src: card.imageUrl, alt: '' }) : null, card.name)))
  },
})
```

`render` 的参数：

| 字段 | 含义 |
|---|---|
| `place` | `'library'`（人物卡库）或 `'play'`（开始游玩窗口） |
| `cards` | 已按搜索和分组筛选、排好序的卡片：`{ path, name, fileName, imageUrl, script, group, starred, error }`。`imageUrl` 没有封面时为空字符串；`script` 是 `{ title }` 或 `null`；`group` 未分组时为空字符串；`error` 是卡片读取失败的原因，正常时为空字符串 |
| `busy` | Tavern 正在导入、删除等操作，期间不要让用户点卡 |
| `selecting` | 是否处于批量管理 |
| `isSelected(path)` | 批量管理时这张卡是否已选 |
| `toggle(path)` | 批量管理时勾选或取消；不在批量管理时什么也不做 |
| `open(path)` | 等于点内置列表的一行：批量管理时勾选或取消，否则在人物卡库打开详情、在开始游玩窗口开局（读取失败的卡不开局） |
| `menu(path)` | Tavern 自己的「⋯ 移到分组」菜单，可放在卡片角上；开始游玩窗口和批量管理时为 `null` |
| `mention(path)` | Tavern 自己的「@ 在对话中引用」按钮，点了把这张卡引用进卡片工作台的输入框，可放在卡片角上；只在卡片工作台的人物卡库、且不在批量管理时有，其余为 `null` |

- `id` 只能用小写字母、数字、点、下划线和连字符；`label` 1–20 字。
- 某一处不想换（例如只想改人物卡库），对那个 `place` 返回 `null`，那里继续用内置列表。
- 显示出错时自动换回内置列表，错误写进错误提示；切换按钮仍在，用户可以重新选。插件卸载后切换消失，回到内置列表。
- 列多少、每格多大、键盘怎么走、Shift 连选这类交互都由插件自己做；`cards` 的顺序就是内置列表的顺序。

## `registerStatusSection({ id, title, render })`（第 3 版）

在这一局的「酒馆状态」页加一节插件自己的内容，排在 Tavern 自己的各节之后，例如当前场景、好感度、导演状态。和 `registerPanel` 的区别：面板是单独的一页，要玩家从「＋」里打开；状态分节和本局状态放在一起，打开状态页就能看到。

```js
ctx.tavernUi.registerStatusSection({ id: 'scene', title: '当前场景', render: ({ gameId }) => h(SceneSummary, { gameId }) })
```

- `id` 规则同 `registerPanel`；`title` 1–20 字，Tavern 画成这一节的标题。
- 出错时这一节只显示一行错误，状态页其余部分照常。卡内插件的分节只出现在它那张卡的局里。插件卸载时自动移除。

## `registerTurnView({ id, label, render })`（第 3 版）

换一种方式显示**整轮正文**，例如对话气泡、剧本排版。`render` 收到 Tavern 自己渲染好的这一轮正文作 `children`，插件可以在外面包一层、在前后加东西，或者自己重画；正文本身（存档里的内容）不变。

```js
ctx.tavernUi.registerTurnView({
  id: 'bubble', label: '气泡',
  render({ gameId, turn, settled, streaming, greeting, text, lines, children }) {
    if (!settled || !lines.length) return null        // 还在生成、或没有对话气泡时用 Tavern 自己的
    return h(BubbleTurn, { lines, text, fallback: children })
  },
})
```

| 字段 | 含义 |
|---|---|
| `turn`、`settled`、`streaming` | 第几轮；是否已写完；是否正在生成（生成中也会调用） |
| `greeting` | 是不是开场白 |
| `text` | 这一轮模型写的原文 |
| `lines` | 这一轮对话气泡的台词（同宿主侧 `getCast` 的 `lines`），写完前或没有气泡时为空数组 |
| `children` | Tavern 自己渲染好的这一轮正文（含人物卡的 HTML 界面、正文标记、插件媒体的位置） |

- 每一轮只由收尾的那一步显示一次，不会重复。
- 注册后默认用插件的样式；「酒馆状态」页出现「正文样式」选择，玩家可以选回内置，这台浏览器记住选择（卡内插件带的样式按卡记住）。插件卸载后回到内置。
- `render` 返回 `null` 或出错时用 Tavern 自己的显示，错误写进错误提示。卡内插件的样式只用于它那张卡的局。

## `getStage(gameId, { count? })`、`watchStage(gameId, listener)`（第 2 版）

舞台要显示的东西：`{ enabled, player, card, background, characters, turns }`。`background` 是人物卡带的主背景图地址，没有时为空字符串。`turns` 是最近 `count` 轮（默认 5，最多 10）的 `{ turn, text, lines }`，`text` 是去掉 HTML 块的正文，`lines` 同宿主侧 `getCast`（没有气泡时为空数组）；`characters` 同宿主侧 `getCastAssets`；`enabled` 是这张卡是否打开了舞台。`watchStage` 先回调一次，之后在新的一轮、素材变化后再回调，只在这一局在当前页面打开时有效。

## `registerStageView`（已停用）

插件不能再替换舞台画面。舞台由 Tavern 按人物卡绑定的素材包绘制：给人物卡绑定素材包并打开这张卡的舞台即可。调用 `registerStageView` 不会注册任何视图，只在错误提示里报告这次调用。要在舞台里给玩家一个整页界面（状态、地图等），写成人物卡自带的卡页面（`stage-status-panel`），不需要插件。

## `speak({ gameId, speaker?, text, emotion?, narration? })`、`stopSpeech()`（第 2 版）

在当前页面朗读一句，用玩家选的配音渠道和这个人物的声音（浏览器朗读也可以）。返回的 Promise 在读完时为 `true`，被打断、配音关闭或失败时为 `false`。同一时间只读一句，新的一句会打断正在读的；`stopSpeech()` 立即停止。适合在插件自己的面板里逐句朗读。

## `components`（第 9 版）

酒馆自己的控件：`{ Slider, Segmented, Switch, SearchBox, Icon, Spinner, EmptyState }`。插件的界面用它们，外观、键盘操作和酒馆一致；参数与酒馆内部相同（如 `h(Slider, { label, min, max, step, value, onChange, output })`、`h(Segmented, { label, value, options: [[值, 文字], …], onChange })`、`h(Icon, { name: 'speaker', size: 16 })`）。

## `registerHeaderTool({ id, render })`（第 9 版）

在一局游戏的顶栏（背景音乐旁边）放一个小工具。`render({ gameId, menu })` 返回 React；手机上顶栏收进 ⋯ 菜单，这时 `menu` 为 `true`，应画成一行菜单项（`role: 'menuitem'`）。同一插件的 `id` 不能重复；插件停用时自动撤掉。

## 朗读正文：`readingUnits`、`prepareReading`、`playReading`、`pauseReading`、`resumeReading`、`stopReading`、`tuneReading`、`readingVoices`（第 9 版）

按舞台的读法朗读整局正文，用酒馆的语音播放器（和气泡 ▶ 同一个声音、同一份缓存）。

- `readingUnits(gameId)` → 每条写完的回复拆成的朗读单位，按顺序：`{ key, row, floor, n, para, kind: 'line' | 'narration', text, speaker }`。`row` 是正文里那一楼的 `data-row-key`，`text` 是页面上显示的字，`para` 相同的单位属于同一段。
- `playReading(gameId, key, options)` 读一个单位，读完时 Promise 得到 `{ ended: true }`，被停止或被别的声音取代时 `{ stopped: true }`，没有可读的 `{ skipped: true }`，读不出来 `{ error: 代码 }`。`options`：`voice`（`null` = 旁白声音，`{ figure: { packId, figureId } }` 素材库人物，`{ browser: 声音 id }` 系统声音）、`lines`（`'figure'` 台词按角色自己的声音，`'reader'` 全用朗读声音）、`volume`（0–1）、`rate`、`onStart()`（声音开始时调用）。
- `prepareReading(gameId, key, options)` 提前合成，不播放；`pauseReading()` / `resumeReading()` 暂停、继续正在读的那句（没有时返回 `false`）；`stopReading()` 停止；`tuneReading({ volume, rate })` 立即改正在读的那句。
- `readingVoices()` → 可选的朗读声音 `[{ key, group, name, value }]`（素材库里有声音的人物和系统声音），`value` 直接传给 `options.voice`。

## `holdVoice()`（第 9 版）

占住酒馆的声音通道：占着时舞台和正文气泡都不配音（没有自动配音，气泡上也没有 ▶），正在说的那句停下。返回释放函数；插件停用时自动释放。适合「有声书」这类自己读正文的插件。

## `playMusic(url | { url, title?, volume? })`、`stopMusic()`（第 2 版）

背景音乐由 Tavern 播放：同一时间一首、循环；传入同一个地址时接着放，换地址时淡入新曲，传空字符串或调 `stopMusic()` 时淡出。玩家在舞台上方的「♪ 音乐」开关决定听不听得到（记在这个浏览器里），所有卡的音乐都受这一个开关管。离开这一局（切换、删除对话）或这一局不再显示舞台时，Tavern 会停掉音乐；插件换局后要重新调 `playMusic`。`volume` 为 0–1，默认 0.45。
